const joi = require("joi");
const UserValidation = joi.object({
  name: joi.string().required(),
  email: joi.string().email().required(),
  password: joi.string().min(3).required(),
});

module.exports=UserValidation;